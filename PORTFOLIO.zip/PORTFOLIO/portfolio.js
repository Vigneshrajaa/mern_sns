addEventListener ("click",function(){
   var down = document.querySelector(".btn-2")
   down = "a.href="
})